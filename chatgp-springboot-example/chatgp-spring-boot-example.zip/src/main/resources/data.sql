INSERT INTO user (name, email) VALUES ('John Doe', 'john.doe@example.com');
INSERT INTO user (name, email) VALUES ('Jane Doe', 'jane.doe@example.com');
